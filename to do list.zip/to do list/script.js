document.addEventListener("DOMContentLoaded", function() {
    document.querySelector('#taskInput').addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            addTask();
        }
    });
});

function addTask() {
    const taskInput = document.getElementById('taskInput');
    const taskList = document.getElementById('taskList');
    const task = taskInput.value;

    if (task === '') {
        alert('Please enter a task');
        return;
    }

    const li = document.createElement('li');
    li.innerHTML = `
        <span>${task}</span>
        <button onclick="removeTask(this)">Delete</button>
    `;
    li.addEventListener('click', function() {
        this.classList.toggle('completed');
    });

    taskList.appendChild(li);
    taskInput.value = '';
}

function removeTask(button) {
    const li = button.parentElement;
    li.parentElement.removeChild(li);
}
